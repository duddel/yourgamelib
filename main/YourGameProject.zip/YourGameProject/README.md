# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    80da922862e90afdf680ad9b0ddfd50d0d47fd1b

Visit <https://github.com/duddel/yourgamelib> for more information.