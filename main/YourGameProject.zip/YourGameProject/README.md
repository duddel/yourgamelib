# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    4d1e87d63c0cc97e03d35b4ac2482d5592d5f7bb

Visit <https://github.com/duddel/yourgamelib> for more information.