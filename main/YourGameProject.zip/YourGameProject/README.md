# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    262abf6b6d4c56406bd074e74d32315008fe5da8

Visit <https://github.com/duddel/yourgamelib> for more information.