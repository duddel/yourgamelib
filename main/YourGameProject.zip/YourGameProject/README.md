# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    891e9275cc1f79d5b5a085fa57f9c2edb5de822e

Visit <https://github.com/duddel/yourgamelib> for more information.