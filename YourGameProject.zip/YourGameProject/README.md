# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    668496d3b1765532be0b3ece1e558031ec7823a7

Visit <https://github.com/duddel/yourgamelib> for more information.