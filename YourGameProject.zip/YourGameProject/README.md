# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    635f2401e89c78f0ec1c2174d7bb7b57de657f46

Visit <https://github.com/duddel/yourgamelib> for more information.