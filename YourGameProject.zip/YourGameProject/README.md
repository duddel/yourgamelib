# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    d5fb465eb6fd76c15228dbb0ee537a6ee5305efa

Visit <https://github.com/duddel/yourgamelib> for more information.