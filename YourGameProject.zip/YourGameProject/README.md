# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    5dcbad218e7b4a5f4d0343f8a46c127c505e73b9

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.