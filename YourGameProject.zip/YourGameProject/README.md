# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    b66e5ddf740c55128c784d9b29dd4d4fc751473d

Visit <https://github.com/duddel/yourgamelib> for more information.