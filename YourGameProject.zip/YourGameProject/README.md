# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    176a2670f584c1d286a6e01f8f699e285c44f520

Visit <https://github.com/duddel/yourgamelib> for more information.