# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    4fcc074aead6c502f18aaa5522ac1bc0d1c9861c

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.