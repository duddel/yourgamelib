# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    01b94e4b977866120ce9581c5c98432eedd92361

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.