# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    303fc543329b9455c426daea4ffaf580b884b7ba

Visit <https://github.com/duddel/yourgamelib> for more information.