# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    d882cdfd56f41cb3accdffaa8e78f90c327ba8f1

Visit <https://github.com/duddel/yourgamelib> for more information.