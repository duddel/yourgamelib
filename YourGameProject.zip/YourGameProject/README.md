# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    ee2485f8c8ada22d75ce45dadea23d76fbf61af8

Visit <https://github.com/duddel/yourgamelib> for more information.