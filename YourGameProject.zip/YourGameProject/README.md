# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    a59736f3624c86dcc885ed445edc515567112929

Visit <https://github.com/duddel/yourgamelib> for more information.