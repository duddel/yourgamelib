# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    ad6d480fd34376b85fe0a96aab65873a0d25ca09

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.