# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    5cac750b5b7d84aa3e3c9c04b530dd9056e5dbd4

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.