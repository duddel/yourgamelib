# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    771ab94e1954ddd948a3ab713082e46ea74d0c1d

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.