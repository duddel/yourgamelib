# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    74254a0a8726b6c746796bddba57e853a75dcb92

Visit <https://github.com/duddel/yourgamelib> for more information.