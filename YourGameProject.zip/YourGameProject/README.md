# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    fdfee5faf15c017fe211182655856bf94ded6887

Visit <https://github.com/duddel/yourgamelib> for more information.