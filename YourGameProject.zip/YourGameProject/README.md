# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    246174401ecedf8dcec6a50a60c657d70e278771

Visit <https://github.com/duddel/yourgamelib> for more information.