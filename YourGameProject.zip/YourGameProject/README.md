# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    1fff8412433c7a713a67b2a5f6cac5042a43b4ec

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.