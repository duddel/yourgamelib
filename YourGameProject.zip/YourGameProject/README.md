# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    fa3a67a0a0aea5c15d4c85bea10dc1dd96cb24d4

Visit <https://github.com/duddel/yourgamelib> for more information.