# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    8a877d45e3b8197e500e0425146b1a09c0f97bf2

Visit <https://github.com/duddel/yourgamelib> for more information.