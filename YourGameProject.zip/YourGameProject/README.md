# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    106ceb976c84d9ddf5525c28610b3bd1d72841b9

Visit <https://github.com/duddel/yourgamelib> for more information.