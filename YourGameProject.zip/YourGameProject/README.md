# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    945131c604f2ccccbcc4b53ac4013d92130aa413

Visit <https://github.com/duddel/yourgamelib> for more information.