# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    3305342491c9fb4d641928531b1ba1e0ce4dd888

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.