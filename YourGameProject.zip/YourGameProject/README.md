# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    aabef6cd09f74c31bb56ad49d3efc43378b7c617

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.