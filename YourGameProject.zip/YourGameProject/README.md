# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    34b3310fb082271c533a352febd71be1451e2f47

Visit <https://github.com/duddel/yourgamelib> for more information.