# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    9e78fb6582c396f4b0cc9e2d334b23afeb2c2759

Visit <https://github.com/duddel/yourgamelib> for more information.