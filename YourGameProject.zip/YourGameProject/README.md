# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    0a78db796f24907e606763221001a4f2e0045c3a

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.