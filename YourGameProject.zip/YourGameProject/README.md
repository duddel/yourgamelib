# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    b4b36b67f1bd98f8cffb7a666fedb9f490474e11

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.