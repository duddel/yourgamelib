# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    f982d1f49aa0621a7647eef1eac50dc18dbff70b

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.