# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    8e76af64907b4f7e025b94baef5c9b193f8e5f6f

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.