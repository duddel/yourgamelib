# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    404e72419e528f71b830c5dc8d3c1c4bfb4c9177

Visit <https://github.com/duddel/yourgamelib> for more information.