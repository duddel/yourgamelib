# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    31a27b136d260764f8c041ee2c2d74925c3c26c5

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.