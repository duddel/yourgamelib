# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    a926b71928548368f125bf70943a37b19a93c833

Visit <https://github.com/duddel/yourgamelib> for more information.