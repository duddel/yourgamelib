# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    0225123e0166f1d2f2a7b6c97180b979e11bd794

Visit <https://github.com/duddel/yourgamelib> for more information.