# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    6dbf248f64ae62696a0b072b74891537b3d73097

Visit <https://github.com/duddel/yourgamelib> for more information.