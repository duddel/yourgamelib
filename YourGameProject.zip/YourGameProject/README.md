# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    9097313518cb2310e72736ec377d77fba7a41ac0

Visit <https://github.com/duddel/yourgamelib> for more information.