# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    37353724737de389aeea1205accbf99c7a7a24e6

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.