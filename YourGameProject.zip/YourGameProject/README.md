# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    98e40bf50af90014a8e292c211cea471a5ed5751

Visit <https://github.com/duddel/yourgamelib> for more information.