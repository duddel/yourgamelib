# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    75b2102aaa1ac3b619ab41ae6f4378454db186c3

Visit <https://github.com/duddel/yourgamelib> for more information.