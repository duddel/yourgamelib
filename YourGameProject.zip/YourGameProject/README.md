# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    64f480e1d75898c558be4172625eae6c67861fd8

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.