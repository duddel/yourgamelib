# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    6246b71cd7a5c17f09b2579cd3d7316923f687fd

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.