# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    af6bbe78a86dbffe13b91a4cbd49073a3b19bbfc

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.