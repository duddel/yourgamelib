# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    af912d730332efe7ce80d06763f0fc0cf0b44e27

Visit <https://github.com/duddel/yourgamelib> for more information.

## LICENSES

For license information, see [`yg_LICENSES.txt`](assets/yg_LICENSES.txt) in the `assets/` directory.