# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    aea8285f7ce20684287b3c0a1d3a74754302c1e8

Visit <https://github.com/duddel/yourgamelib> for more information.